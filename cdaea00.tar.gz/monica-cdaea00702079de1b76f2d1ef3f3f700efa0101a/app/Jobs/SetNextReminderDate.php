<?php

namespace App\Jobs;

use App\User;
use App\Account;
use App\Contact;
use App\Reminder;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;

class SetNextReminderDate implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $reminder;
    protected $user;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct(Reminder $reminder, User $user)
    {
        $this->reminder = $reminder;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $contact = Contact::findOrFail($this->reminder->contact_id);
        $account = Account::findOrFail($contact->account_id);
        $user = User::where('account_id', $account->id)->first();
        $date = $this->reminder->next_expected_date;

        if ($this->reminder->frequency_type == 'one_time') {
            $contact = Contact::findOrFail($this->reminder->contact_id);
            $contact->number_of_reminders = $contact->number_of_reminders - 1;
            $contact->save();

            $this->reminder->delete();
        } else {
            $frequencyType = $this->reminder->frequency_type;
            $frequencyNumber = $this->reminder->frequency_number;
            $startDate = $date;

            $this->reminder->last_triggered = $this->reminder->next_expected_date;
            $this->reminder->calculateNextExpectedDate($startDate, $frequencyType, $frequencyNumber);
            $this->reminder->save();
        }
    }
}
