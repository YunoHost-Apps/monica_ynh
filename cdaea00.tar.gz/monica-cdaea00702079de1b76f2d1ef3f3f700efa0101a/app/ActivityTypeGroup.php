<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ActivityTypeGroup extends Model
{
    protected $table = 'activity_type_groups';
}
