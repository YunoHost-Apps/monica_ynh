<?php

    return [
        'api_key' => 'f98884d6b422d3ac568dd6703ec9f469',
        'routes_enabled' => false,   // If the routes have to be enabled.
    ];
