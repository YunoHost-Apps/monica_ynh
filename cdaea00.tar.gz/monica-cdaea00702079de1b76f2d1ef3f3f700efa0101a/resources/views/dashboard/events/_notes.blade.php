{{-- You added a note about Jane Doe --}}

{{ trans('dashboard.event_note_about') }}

<a href="/people/{{ $event['contact_id'] }}">{{ $event['contact_complete_name'] }}</a>
