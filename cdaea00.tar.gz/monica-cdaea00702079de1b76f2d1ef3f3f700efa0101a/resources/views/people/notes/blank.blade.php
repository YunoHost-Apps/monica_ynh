<div class="blank-note-state">
  <img src="/img/people/dashboard/notes/notes.svg">
  <h3>{{ trans('people.notes_blank_title') }}</h3>
</div>
