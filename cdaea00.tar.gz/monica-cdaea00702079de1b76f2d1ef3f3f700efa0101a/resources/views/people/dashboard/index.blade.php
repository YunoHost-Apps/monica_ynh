{{-- Section address, email, phone, contact --}}
@include('people.dashboard.people-information.index')

{{-- Work --}}
@include('people.dashboard.work.index')

{{-- Significant Other --}}
@include('people.dashboard.significantother.index')

{{-- Kids --}}
@include('people.dashboard.kids.index')

{{-- Food preferences --}}
@include('people.dashboard.food-preferencies.index')
