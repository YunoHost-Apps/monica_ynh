New registration: {{ $user->first_name }} {{ $user->last_name }}

ID: {{ $user->id }}

Email: {{ $user->email }}