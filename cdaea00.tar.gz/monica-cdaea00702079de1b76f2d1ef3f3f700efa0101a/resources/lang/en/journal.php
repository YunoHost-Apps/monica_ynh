<?php

return [
    'journal_add' => 'Add a journal entry',
    'journal_entry_delete' => 'Delete',
    'entry_delete_success' => 'The journal entry has been deleted with success.',
    'journal_add_title' => 'Title (optional)',
    'journal_add_post' => 'Entry',
    'journal_add_cta' => 'Save',
    'journal_blank_cta' => 'Add your first journal entry',
    'journal_blank_description' => 'The journal lets you write events that happened to you, and remember them.',
];
