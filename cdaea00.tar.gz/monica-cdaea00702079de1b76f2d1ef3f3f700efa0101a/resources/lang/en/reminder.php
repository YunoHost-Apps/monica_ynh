<?php

return [
    'type_birthday' => 'Wish happy birthday to',
    'type_phone_call' => 'Call',
    'type_lunch' => 'Lunch with',
    'type_hangout' => 'Hangout with',
    'type_email' => 'Email',
    'type_birthday_kid' => 'Wish happy birthday to the kid of',

];
