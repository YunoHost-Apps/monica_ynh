<?php

return [
    'type_birthday' => 'Souhait d\'anniversaire pour',
    'type_phone_call' => 'Appeler',
    'type_lunch' => 'Manger avec',
    'type_hangout' => 'Aller voir',
    'type_email' => 'Envoyer un email à',
    'type_birthday_kid' => 'Souhaiter l\'anniversaire de l\'enfant de',

];
