<?php

return [
    'journal_add' => 'Ajouter une entrée',
    'journal_entry_delete' => 'Supprimer',
    'entry_delete_success' => 'L\'entrée a été supprimée avec succès.',
    'journal_add_title' => 'Titre (optionel)',
    'journal_add_post' => 'Entrée',
    'journal_add_cta' => 'Sauvegarder',
    'journal_blank_cta' => 'Ajouter votre première entrée dans le journal',
    'journal_blank_description' => 'Le journal vous permet de vous rappeler d\'évènements passés, ou à venir.',
];
