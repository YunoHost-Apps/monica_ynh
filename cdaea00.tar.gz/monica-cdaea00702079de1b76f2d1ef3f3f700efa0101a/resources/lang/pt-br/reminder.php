<?php

return [
    'type_birthday' => 'Desejar feliz aniversário para',
    'type_phone_call' => 'Ligar',
    'type_lunch' => 'Almoçar com',
    'type_hangout' => 'Sair com',
    'type_email' => 'Email',
    'type_birthday_kid' => 'Desejar feliz aniversário para o filho de',

];
