<?php

return [
    'journal_add' => 'Adicionar um registro no diário',
    'journal_entry_delete' => 'Deletar',
    'entry_delete_success' => 'O registro no diário foi eliminada com sucesso.',
    'journal_add_title' => 'Título (Opcional)',
    'journal_add_post' => 'Registro',
    'journal_add_cta' => 'Salvar',
    'journal_blank_cta' => 'Adicione seu primeiro registro no diário',
    'journal_blank_description' => 'O diário permite que você escreva eventos que aconteceram com você, para te lembrar.',
];
