<?php

return [

    'subject_line' => 'Lembrete para :contact',
    'greetings' => 'Olá :username',
    'want_reminded_of' => 'VOCÊ QUER SER LEMBRADO COMO',
    'for' => 'PARA:',
    'footer_contact_info' => 'Adicionar, visualizar, completar e alterar informações sobre este contato:',

];
