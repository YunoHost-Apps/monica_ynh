<?php

return [

    'subject_line' => 'Напоминание для :contact',
    'greetings' => 'Привет :username',
    'want_reminded_of' => 'ВЫ ХОТИТЕ ПОЛУЧИ НАПОМИНАНИЯ',
    'for' => 'О:',
    'footer_contact_info' => 'Добавить, просмотреть, завершить и изменить информацию об этом контакте',

];